<?php
include 'db_connection.php';

if (isset($_GET['id'])) {
    $username = $_GET['id'];

   
    $delete_sql = "DELETE FROM myguests WHERE username = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();

    header("Location: dashboard.php"); 
}
?>
