<?php
include 'db_connection.php';

if (isset($_GET['id'])) {
    $username = $_GET['id'];

  
    $sql = "SELECT firstname, lastname, username, mg_date FROM myguests WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $guest = $result->fetch_assoc();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $mg_date = $_POST['mg_date'];

        $update_sql = "UPDATE myguests SET firstname = ?, lastname = ?, mg_date = ? WHERE username = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssss", $firstname, $lastname, $mg_date, $username);
        $update_stmt->execute();

        header("Location: dashboard.php"); 
        exit();
    }
}
?>

    <title>Create Guest</title>
    <style>
        body {
            background: linear-gradient(to right, #b0d3c1, #87a69a); 
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; 
            margin: 0;
            font-family: 'Ubuntu', sans-serif;
        }

        .container {
            display: flex;
            width: 80%;
            max-width: 1200px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(to right, #b0d3c1, #87a69a); 
            padding: 20px;
        }

        .sidebar h2 {
            color: black; 
            margin-bottom: 20px;
        }

        .sidebar a {
            color: black; 
            text-decoration: none;
            display: block;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: rgba(255, 255, 255, 0.2); 
        }

        .content {
            flex-grow: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            background-color: white; 

        h2 {
            color: #4d4449; 
        }

        form {
            width: 100%;
            max-width: 600px;
        }

        label {
            display: block;
            margin: 10px 0 5px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #b0d3c1;
            border-radius: 5px;
        }

        button {
            background: linear-gradient(to right, #b0d3c1, #87a69a); 
            border: none;
            color: black;
            font-family: 'Ubuntu', sans-serif;
            font-size: 18px;
            padding: 10px 20px; 
            border-radius: 5px; 
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background: linear-gradient(to right, #87a69a, #b0d3c1); 
        }

        .error {
            color: red;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="sidebar">
            <h2>Dashboard</h2>
            <a href="create.php">Create</a>
            <a href="Dashboard.php">Read</a>
            <a href="update1.php">Update</a>
            <a href="delete1.php">Delete</a>
            <a href="logout.php">Logout</a>
        </div>

        <div class="content">
            <h2>Update</h2>
            <?php if (isset($error)): ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
           <form method="post">
            <label>First Name:</label>
            <input type="text" name="firstname" value="<?php echo htmlspecialchars($guest['firstname']); ?>" required>
            <br>
            <label>Last Name:</label>
            <input type="text" name="lastname" value="<?php echo htmlspecialchars($guest['lastname']); ?>" required>
            <br>
            <label>Registration Date:</label>
            <input type="date" name="mg_date" value="<?php echo htmlspecialchars($guest['mg_date']); ?>" required>
            <br>
            <button type="submit">Update</button>
        </form>
        </div>
    </div>

</body>
</html>
