<?php
session_start();

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$database = "jayh";

$conn = new mysqli($servername, $dbUsername, $dbPassword, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8");



?>
