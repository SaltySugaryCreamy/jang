-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2024 at 01:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jayh`
--

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `authors_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `bio` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`authors_id`, `name`, `bio`) VALUES
(1, 'Administrator', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `author_books`
--

CREATE TABLE `author_books` (
  `author_book_isbn` int(11) NOT NULL,
  `author_books_author_id` int(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `genre` varchar(40) NOT NULL,
  `description` varchar(50) NOT NULL,
  `date_published` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `author_books`
--

INSERT INTO `author_books` (`author_book_isbn`, `author_books_author_id`, `title`, `genre`, `description`, `date_published`) VALUES
(1, 0, 'jaybond', 'holliete', 'tupi', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `library_books`
--

CREATE TABLE `library_books` (
  `library_books_id` int(11) NOT NULL,
  `library_books_isbn` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `library_books`
--

INSERT INTO `library_books` (`library_books_id`, `library_books_isbn`) VALUES
(1, 'Standard'),
(2, 'Superior'),
(3, 'Super Deluxe'),
(4, 'Jr. Suite'),
(5, 'Executive Suite'),
(7, 'Jr. Suite');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `members_id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `phone_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `member_books`
--

CREATE TABLE `member_books` (
  `member_books_member_id` int(11) NOT NULL,
  `member_books_id` int(11) NOT NULL,
  `checkout` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `member_books`
--

INSERT INTO `member_books` (`member_books_member_id`, `member_books_id`, `checkout`) VALUES
(1, 1, '0000-00-00 00:00:00.000000'),
(2, 4, '2024-05-27 00:00:00.000000'),
(3, 2, '0000-00-00 00:00:00.000000'),
(5, 5, '2024-05-25 14:36:07.156905');

-- --------------------------------------------------------

--
-- Table structure for table `myguests`
--

CREATE TABLE `myguests` (
  `id` int(50) NOT NULL,
  `Firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `mg_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `myguests`
--

INSERT INTO `myguests` (`id`, `Firstname`, `lastname`, `username`, `mg_date`) VALUES
(1, 'john', 'does', 'johndoe@example', '2024-08-30'),
(3, 'marry', 'moe', 'marry@example', '2024-08-09'),
(4, 'julie', 'dooley', 'jullie@example', '2024-08-10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `lastname`, `firstname`, `username`, `gender`, `email`, `password`) VALUES
(10, 'holliete', 'jaybond', 'jaybond@c', 'male', 'jaybondholliete1@gmail.com', '$2y$10$oC2j0Y7ETPgZCB5/aj34GuFTIdrlXKu14dB1aRZAk27LjhwXD9VMK'),
(15, 'admin', 'admin', 'admin', 'male', 'admin@a', '$2y$10$LBCNNoE7W4lbRQqRMbfvmuG6p9.XAUnT7hR6fsDedJoiKXu9snKIi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`authors_id`),
  ADD UNIQUE KEY `authors_id` (`authors_id`),
  ADD UNIQUE KEY `authors_id_2` (`authors_id`);

--
-- Indexes for table `author_books`
--
ALTER TABLE `author_books`
  ADD PRIMARY KEY (`author_book_isbn`),
  ADD KEY `author_books_author_id` (`author_books_author_id`);

--
-- Indexes for table `library_books`
--
ALTER TABLE `library_books`
  ADD PRIMARY KEY (`library_books_id`);
ALTER TABLE `library_books` ADD FULLTEXT KEY `library_books_isbn` (`library_books_isbn`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`members_id`);

--
-- Indexes for table `member_books`
--
ALTER TABLE `member_books`
  ADD UNIQUE KEY `guest_id` (`member_books_member_id`),
  ADD UNIQUE KEY `room_id` (`member_books_id`),
  ADD UNIQUE KEY `guest_id_2` (`member_books_member_id`);

--
-- Indexes for table `myguests`
--
ALTER TABLE `myguests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `authors_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `author_books`
--
ALTER TABLE `author_books`
  MODIFY `author_book_isbn` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `library_books`
--
ALTER TABLE `library_books`
  MODIFY `library_books_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `myguests`
--
ALTER TABLE `myguests`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
