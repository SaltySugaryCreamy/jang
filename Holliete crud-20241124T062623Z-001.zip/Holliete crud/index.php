<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
  
    <link href="https://fonts.googleapis.com/css?family=Ubuntu:500" rel="stylesheet">
  <link rel="stylesheet" href="style.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script  src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>

    <div class="container">
    <div class="login">
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">

                <i class="fa fa-user" aria-hidden="true">&nbsp;&nbsp;</i><input type="text" name="username" placeholder="Username" required=""><br><br>
                <i class="fa fa-unlock-alt" aria-hidden="true">&nbsp;&nbsp;</i><input type="password" name="pass" placeholder="Password" required=""><br><br>
            <button type="submit">Login</button><br>
            <a href="register.php">Register here</a> 



            <?php
        include 'db_connection.php';
        
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $username = $_POST['username'];
            $password = $_POST['pass'];
            $sql = "SELECT * FROM users WHERE username='$username'";
            $result = $conn->query($sql);
            
            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                if (password_verify($password, $row['password'])) {
                    session_start();
                    $_SESSION['username'] = $username;
                    header("Location: dashboard.php");
                    exit();
                } else {
                    echo "<p style='color:red;'>Incorrect password</p>";
                }
            } else {
                echo "<p style='color:red;'>User not found</p>";
            }
        }
        
        $conn->close();
        ?>
            </form>
</div>
<div class="backg">
  <div class="panda">
    <div class="earl"></div>
    <div class="earr"></div>
    <div class="face">
      <div class="blshl"></div>
      <div class="blshr"></div>
      <div class="eyel">
        <div class="eyeball1"></div>
      </div>
      <div class="eyer">
        <div class="eyeball2"></div>
      </div>
      <div class="nose">
        <div class="line"></div>
      </div>
      <div class="mouth">
        <div class="m">
          <div class="m1"></div>
        </div>
        <div class="mm">
          <div class="m1"></div>
        </div>
      </div>
    </div>
    
  </div>
</div>
<div class="pawl">
  <div class="p1">
      <div class="p2"></div>
      <div class="p3"></div>
      <div class="p4"></div>
      </div>
    </div>
<div class="pawr">
  <div class="p1">
    <div class="p2"></div>
    <div class="p3"></div>
    <div class="p4"></div>
  </div>
</div>
<div class="handl"></div>
<div class="handr"></div>
<script src="script.js"></script>
  </div>
</body>
</html>
