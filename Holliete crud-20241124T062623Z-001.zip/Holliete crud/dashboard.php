<?php
include 'db_connection.php'; 

$sql = "SELECT firstname, lastname, username, mg_date FROM myguests"; 
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            background: linear-gradient(to right, #b0d3c1, #87a69a); 
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; 
            margin: 0;
            font-family: 'Ubuntu', sans-serif;
        }

        .container {
            display: flex;
            width: 80%;
            max-width: 1200px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(to right, #b0d3c1, #87a69a); 
            padding: 20px;
        }

        .sidebar h2 {
            color: black; 
            margin-bottom: 20px;
        }

        .sidebar a {
            color: black; 
            text-decoration: none;
            display: block;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: rgba(255, 255, 255, 0.2); 
        }

        .content {
            flex-grow: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            background-color: white; 
        }

        h2 {
            color: #4d4449; 
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #b0d3c1; 
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #222; 
            color: white; 
        }

        tr:nth-child(even) {
            background-color: #f2f2f2; 
        }

        button {
            background: linear-gradient(to right, #b0d3c1, #87a69a); 
            outline: none;
            border: none;
            color: white;
            font-family: 'Ubuntu', sans-serif;
            font-size: 23px;
            text-transform: uppercase;
            padding: 5px 20px; 
            border-radius: 5px; 
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background: linear-gradient(to right, #87a69a, #b0d3c1); 
    </style>
</head>
<body>

    <div class="container">
        <div class="sidebar">
            <h2>Dashboard</h2>
            <a href="create.php">Create</a>
            <a href="Dashboard.php">Read</a>
            <a href="update1.php">Update</a>
            <a href="delete1.php">Delete</a>
            <a href="logout.php">Logout</a>
        </div>

        <div class="content">
            <h2>Read</h2>
            <table>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Registration Date</th>
                </tr>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($guest = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($guest['firstname']); ?></td>
                        <td><?php echo htmlspecialchars($guest['lastname']); ?></td>
                        <td><?php echo htmlspecialchars($guest['username']); ?></td>
                        <td><?php echo htmlspecialchars($guest['mg_date']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">No guests found.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

</body>
</html>
