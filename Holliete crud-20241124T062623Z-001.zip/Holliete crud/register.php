<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <style>
        body {
            background: linear-gradient(to right, #b0d3c1, #87a69a); 
            color: #fff; 
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        h2 {
            color: #ffcccb; 
            margin-bottom: 20px;
        }
        form {
            background-color: #222; 
            padding: 40px; 
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(255, 204, 203, 0.5); 
            width: 300px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        form:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 20px rgba(255, 204, 203, 0.7); 
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: calc(100% - 24px); 
            padding: 12px;
            margin: 10px 0;
            border: 2px solid #ffcccb; 
            border-radius: 5px;
            background-color: #333; 
            color: #fff; 
            transition: border-color 0.3s ease;
        }
        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #ff99a1; 
            outline: none;
        }
        button {
            background: linear-gradient(to right, #b0d3c1, #87a69a); 
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            transition: background-color 0.3s ease;
            margin-top: 10px; 
        }
        button:hover {
            background-color: #ff99a1; 
        }
        label {
            margin: 10px 0 5px;
            display: block;
        }
        .gender {
            margin: 10px 0;
        }
        a {
            color: #ffcccb; 
            text-decoration: none;
            display: block;
            margin-top: 10px;
            text-align: center;
            transition: color 0.3s ease;
        }
        a:hover {
            color: #ff99a1; 
            text-decoration: underline;
        }
        .error {
            color: red;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
   
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
         <h2>Registration Form</h2>
         <label for="lname">Last Name:</label>
        <input type="text" name="lname" required>
        
        <label for="fname">First Name:</label>
        <input type="text" name="fname" required>
        
        <label for="username">Username:</label>
        <input type="text" name="username" required>
        
        <div class="gender">
            <label>Gender:</label>
            <input type="radio" name="gender" value="male" required> Male
            <input type="radio" name="gender" value="female"> Female
            <input type="radio" name="gender" value="other"> Other
        </div>
        
        <label for="email">Email:</label>
        <input type="email" name="email" required>
        
        <label for="pass">Password:</label>
        <input type="password" name="pass" required minlength="8">
        
        <button type="submit">Register</button> 

         <?php
    include 'db_connection.php';
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $lastname = $_POST['lname'];
        $firstname = $_POST['fname'];
        $username = $_POST['username'];
        $gender = $_POST['gender'];
        $email = $_POST['email'];
        $password = password_hash($_POST['pass'], PASSWORD_DEFAULT);
        
        $check_username_sql = "SELECT id FROM users WHERE username = '$username'";
        $check_username_result = $conn->query($check_username_sql);
        
        if ($check_username_result->num_rows > 0) {
            echo "<p class='error'>Username already exists. Please choose a different one.</p>";
        } else {
            if (empty($lastname) || empty($firstname) || empty($gender) || empty($email) || empty($username) || empty($password)) {
                echo "<p class='error'>Please fill in all the fields.</p>";
            } elseif (strlen($_POST['pass']) < 8) {
                echo "<p class='error'>Password must be at least 8 characters long.</p>";
            } else {
                $sql = "INSERT INTO users (lastname, firstname, username, gender, email, password) VALUES ('$lastname', '$firstname', '$username', '$gender', '$email', '$password')";
                if ($conn->query($sql) === TRUE) {
                    header("Location: index.php"); 
                    exit();
                } else {
                    echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
                }
            }
        }
    }
    
    $conn->close();
    ?>
    </form>

    

</body>
</html>