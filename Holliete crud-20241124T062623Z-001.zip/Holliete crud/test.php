<html> 
<head> </head> 
<body> 
<?php echo "Page content"; 
?> 
</body> 
</html>


